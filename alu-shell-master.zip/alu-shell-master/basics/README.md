Manipulating Files
What do the commands cp, mv, rm, mkdir do
What are wildcards and how do they work
How to use wildcards
